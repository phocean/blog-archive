#!/usr/bin/perl -w

# VER. 0.2 - http://www.phocean.net
# Copyright (c) 2007 Jean-Christophe Baptiste (jc@phocean.net)
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

=pod

=head1 Isakmp-manager v0.1

=head2 Description

Monitor Isakmp remotely using a socket connection

=head2 Open the socket on the server machine

./Isalmp-manager &

=head3 Client calls

Just send a specific command to the socket. For example, you can use your own scripting or netcat :

Ex. : echo "restart" | netcat 10.80.1.1 35000

Below, the list of available commands :

=over

=item* status

gives back the status of Isakmpd : its PID value if started, otherwise -1 error code.

=item* start

start the Isakmpd service and gives back its PID value if successful, or -1 in case of error.

=item* stop

stop the Isakmpd service (SIGTERM) and gives back 0 if successful, or -1 in case of error.

=item* restart

restart the isakmpd service and gives back the new PID value if successful, or -1 in case of error.

=item* reload

force Isakmpd to reload its configuration file and returns 0 if successful, or -1 in case of error.

=item* kill

kill Isakmpd (SIGKILL) and returns 0 if successful, or -1 in case of error.

=back

=cut

#use lib "/opt/ActivePerl-5.8/site/lib";
use strict;
use warnings;
use Getopt::Std;
use NetServer::Generic;
use Proc::ProcessTable; 

# opening the socket
sub isaksrv {
	my $server = new NetServer::Generic;
	$server -> port(35000);
	$server -> callback($_[0]);
	$server -> mode("select");
	my ($allowed) = ['10\.80\.1\.2'];
	$server -> allowed($allowed);  
	print "A l'écoute sur le port ".$server->port."\n";
	$server -> run();
};

# gives backthe PID
sub isakpid {
	my $t = Proc::ProcessTable->new();
	my $isak;
	for my $p (@{$t->table}) {
   		$isak = $p if ($p->fname eq 'isakmpd' && $p->uid == 68);
	}
	if (defined $isak) {
		return ($isak->pid);
	}
	else {
		return (-1);
	}
};

# send a kill signal to a process
sub isakkill {
	my $t = Proc::ProcessTable->new();
	my $isak;
	for my $p (@{$t->table}) {
   		$isak = $p if ($p->pid == $_[0]);
	}
	if (defined $isak) {
		$isak->kill($_[1]);
		return (0);
	}
	else {
		return (-1);
	}
};

# stop Isakmpd
sub isakstop {
	my $res = isakpid;
	if ($res == -1) {
		print "Impossible d'arrêter isakmpd, aucun processus n'est en cours d'exécution\n";
		return (-1);
	}
	else {
		print "Arrêt du démon Isakmpd de PID ".$res."\n";
		return (isakkill ($res,15));
	}
};

# kill Isakmpd
sub isakkiller {
	my $res = isakpid;
	if ($res == -1) {
		print "Impossible d'arrêter isakmpd, aucun processus n'est en cours d'exécution\n";
		return (-1);
	}
	else {
		print "Arrêt du démon Isakmpd de PID ".$res."\n";
		return (isakkill ($res,9));
	}
};

# start isakmpd
sub isakstart {
	my $res = isakpid;	
	if ($res == -1) {
		system('isakmpd');
		sleep (6);
		my $res1 = isakpid;
		print "Isakmpd démarré avec le PID ".$res1."\n";
		return $res1;	
	}		
	else {
		print "Impossible de démarrer isakmpd, un processus (pid : ".$res.") est déjà en cours d'exécution\n";
		return -1;
	}
};

# restart isakmpd
sub isakrestart {
	isakstop;
	sleep (8);
	return (isakstart);
};

# reload isakmpd
sub isakreload {
	my $res = isakpid;
	if ($res == -1) {
		print "Impossible de recharger isakmpd, aucun processus n'est en cours d'exécution\n";
		return -1;
	}
	else {
		print "Rechargement du démon Isakmpd de pid : ".$res."\n";
		return (isakkill ($res,1));
	}
};

# status of isakmpd
sub isakstatus {
	my $res = isakpid;
	if ($res == -1) {
		print "isakmp n'est pas en cours d'exécution\n";
		return 0;
	}
	else {
		print "Le pid de isakmpd est : ".$res."\n";
		return $res;
	}
};

# socket routine
my $isakrun = sub {
	my $tmp;
	my ($fh) = shift ;
	while (defined ($tmp = <STDIN>)) {
		chomp $tmp;
        	if ($tmp eq 'restart') {
        	        isakrestart;
        	        return 0;
        	} 
        	elsif ($tmp eq 'stop') {
        	        isakstop;
        	        return 0;
        	} 
		elsif ($tmp eq 'start') {
	                isakstart;
	                return 0;
	        } 
		elsif ($tmp eq 'reload') {
        	        isakreload;
        	        return 0;
        	} 
		elsif ($tmp eq 'status') {
        	        isakstatus;
        	        return 0;
        	} 
		elsif ($tmp eq 'kill') {
        	        isakkiller;
        	        return 0;
        	} 
        	else {
                	print STDOUT "Commande inconnue\n\n";
            	}
        }
        return 0;
 }; 

# MAIN
isaksrv ($isakrun);
