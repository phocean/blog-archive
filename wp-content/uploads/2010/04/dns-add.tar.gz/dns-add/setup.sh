#!/bin/bash

gcc dns-add.c -o /bin/dns-add
echo "done, run dns-add"