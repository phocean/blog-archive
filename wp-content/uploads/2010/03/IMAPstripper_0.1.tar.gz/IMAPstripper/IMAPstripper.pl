#!/usr/bin/perl -w

# Jean-Christophe Baptiste <jc@phocean.net>
# v0.1 - 03/06/2007 - GPL v2

use lib "/opt/ActivePerl-5.8/site/lib";
use strict;
use warnings;
use MIME::Parser;
use Mail::IMAPTalk qw(:utf8support);
use Getopt::Std;
my %opts; my $res;

sub connexion {
print "Connecting to IMAP server at ".$_[0].":".$_[1]."...\n";
# ouverture de la connexion avec IMAP::Talk
my $imap = Mail::IMAPTalk->new(
Server => $_[0],
Port => $_[3],
Username => $_[1],
Password => $_[2],
Separator => '.',
RootFolder => 'Inbox',
CaseInsensitive => 1,
ParseOption => 'DecodeUTF8',
)
|| die "Connection failed. Reason: $@";

# select the IMAP folder and the last not seen message
$imap->select($_[4]) || die $@;
my $MsgId = $imap->search('not', 'seen')->[0];
#my $MsgId=1;
if ($MsgId) {
# Fetch the message body as a MIME object
my $MsgTxt = $imap->fetch($MsgId, "body[]")->{$MsgId}->{body} || die "Can't fetch the message !";
print "IMAP connection successful !\n";
return ($MsgTxt);
}
else {use Data::Dumper;
die "No new message in the mailbox\n";
}
}

sub parseur {
# Create a new MIME::Parser object
my $parser = new MIME::Parser;
# Tolerant mode
$parser->ignore_errors(1);
# Output to a file
$parser->output_to_core(0);
# Output to a per message folder
$parser->output_under("./extracted");
# Prefix for the extracted message
$parser->output_prefix("msg");
# Parsing the message
my $entity = $parser->parse_data($_[0]);
my $error = ($@ || $parser->last_error);
if ($error) {
print $error."\n";
}
else {
print "Attachment extracted !\n";
}
# Delete the files containing the message content (we want only the attachment)
chdir (".");
unlink $entity->{'ME_Parts'}[0]->{'ME_Bodyhandle'}->{'MB_Path'} || die ("Can't delete the message body file !");
}

# command line options
getopts('s:l:p:P:F:', \%opts);
die("\n -- Mail_extract--\n".
"\n".
" Mail_Extract take off the attachement from the last arrived message in an IMAP box\n".
" Files are in the ./extracted directory\n".
"\n".
"Usage: $0 {Mode} [options]\n".
"\n".
" Required :\n".
" -s [server] Name or IP address of the IMAP server\n".
" -l [login] Login of the IMAP mailbox\n".
" -p [password] IMAP password\n".
" Options :\n".
" -P [port] IMAP port (default : 143)\n".
" -F [folder] IMAP folder to fetch (default : INBOX)\n".
"")
unless ($opts{'s'} && $opts{'l'} && $opts{'p'}
|| ($opts{'s'} && $opts{'l'} && $opts{'p'} && $opts{'P'})
|| ($opts{'s'} && $opts{'l'} && $opts{'p'} && $opts{'F'})
|| ($opts{'s'} && $opts{'l'} && $opts{'p'} && $opts{'P'} && $opts{'F'})
);
$opts{'P'}=143 unless $opts{'P'};
$opts{'F'}='INBOX' unless $opts{'F'};

# establish IMAP connection
$res = connexion ($opts{'s'},$opts{'l'},$opts{'p'},$opts{'P'},$opts{'F'});
# parse the message
parseur ($res);
